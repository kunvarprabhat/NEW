﻿using APPII.Model;
using Microsoft.AspNetCore.Mvc;

namespace APPII.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class PlayersController : ControllerBase
    {
        private static List<IplPlayer> _players;

        public PlayersController()
        {
            _players = new List<IplPlayer>()
            {
                new IplPlayer(){Id=1, JerseyNumber=1, Name="Virat Kohli", Team="Rcb" },
                new IplPlayer(){Id=2, JerseyNumber=45, Name="Rohit Sharma", Team="Mumbai Indian" },
                new IplPlayer(){Id=3, JerseyNumber=7, Name="MS Dhoni", Team="Chennai" }
            };
        }
        [HttpGet(Name = "GetIplPlayers")]
        public IEnumerable<IplPlayer> Get()
        {
            return _players;
        }


        [HttpGet]
        [Route(template: "GetById")]
        public IActionResult Get(int Id)
        {
            return Ok(_players.FirstOrDefault(x => x.Id == Id));

        }

        [HttpPost]
        [Route(template: "AddPlayer")]

        public IActionResult AddPlayer(IplPlayer player)
        {
            _players.Add(player);
            return Ok();
        }

        [HttpDelete]

        [Route(template: "DeletePlayer")]
        public IActionResult DeletePlayer(int id)
        {
            var pl = _players.FirstOrDefault(x => x.Id == id);
            if (pl == null)
            {
                return NotFound();
            }
            else
            {
                _players.Remove(pl);
                return NoContent();
            }


        }
        [HttpPatch]
        [Route(template: "UpdatePlayer")]
        public IActionResult UpdatePlayer(IplPlayer player)
        {
            var existPl = _players.FirstOrDefault(x => x.Id == player.Id);
            if (existPl == null)
            {
                return NotFound();
            }
            else
            {
                existPl.Name = player.Name;
                existPl.Team = player.Team;
                existPl.JerseyNumber = player.JerseyNumber;
                return Ok();
            }
        }

    }
}

